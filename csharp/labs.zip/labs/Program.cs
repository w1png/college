﻿namespace Labs {
  class Program {
    static void Main() {
      Console.WriteLine("Лабораторная работа №5");
      Lab5.Run();
      Console.WriteLine("-------");

      Console.WriteLine("Лабораторная работа №6");
      Lab6.Run();
      Console.WriteLine("-------");

      Console.WriteLine("Лабораторная работа №7");
      Lab7.Run();
      Console.WriteLine("-------");

      Console.WriteLine("Лабораторная работа №8");
      Lab8.Run();
      Console.WriteLine("-------");

      Console.WriteLine("Лабораторная работа №9");
      Lab9.Run();
      Console.WriteLine("-------");

      Console.WriteLine("Лабораторная работа библиотеки");
      LabLibraries.Run();
      Console.WriteLine("-------");
    }
  }
}
